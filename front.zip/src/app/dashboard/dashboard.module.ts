import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { httpInterceptorProviders } from '../core/interceptors';

import { CoreModule } from '../core/core.module';

import { AuthService } from '../auth/services/auth.service';

@NgModule({
  declarations: [DashboardComponent],
  providers: [httpInterceptorProviders, AuthService],
  imports: [CommonModule, DashboardRoutingModule, HttpClientModule, CoreModule],
})
export class DashboardModule {}
