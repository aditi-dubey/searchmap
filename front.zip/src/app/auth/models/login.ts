export class Login {
  username: String;
  password: String;
}
