import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from '../../models/register';
import { AuthService } from '../../services/auth.service';
import { AlertService } from 'src/app/core/services/alert.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();

  constructor(
    private authService: AuthService,
    private router: Router,
    private alertService: AlertService
  ) {}

  registerSubmit() {
    console.log(JSON.stringify(this.register));

    const newUser: any = {
      username: this.register.username,
      email: this.register.email,
      password: this.register.password,
    };
    // Here in subscribe we have two things success and failure part (sucess is then part and failure is catch part according to axios)
    this.authService.registerUser(newUser).subscribe(
      (res) => {
        console.log('User registered successfully');
        this.router.navigate(['/auth/login']);
        this.alertService.setAlert({
          alertType: 'success',
          message: 'Register Success',
        });

        console.log(JSON.stringify(res)); //if login->success --->generates a token=>prints token
        localStorage.setItem('token', res.token);
      },
      (err) => {
        // if (newUser.username == null) {
        //   this.alertService.setAlert({
        //     alertType: 'danger',
        //     message: 'Name should not be null',
        //   });
        // } else
        if (newUser.email == null) {
          this.alertService.setAlert({
            alertType: 'danger',
            message: 'Email should not be null',
          });
        }
        // else if (newUser.password == null || newUser.password2 == null) {
        //   this.alertService.setAlert({
        //     alertType: 'danger',
        //     message: 'Password should not be null',
        //   });
        // }
      }
    );
  }
  ngOnInit(): void {}
}
